namespace DIO.series
{
    public abstract class EntidadeBase
    {
        public ind Id { get; protected set; }
    }
}